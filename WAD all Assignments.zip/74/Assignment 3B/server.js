const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const authRoutes = require('./routes/auth');

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb+srv://tayadeyash9607_db_user:kXULBnrP04EZuKG3@cluster0.ztbjbsi.mongodb.net/mongodb')
.then(() => console.log('MongoDB Connected'))
.catch(err => console.log(err));

app.use('/api', authRoutes);

app.listen(5000, () => {
    console.log('Server running on port 5000');
});